#include "Consultes.hh"
#include <set>

bool Consultes::classcomp::operator() (const Autor& lhs, const Autor& rhs) const
{
    return lhs.consultar_nom() < rhs.consultar_nom();
}
bool Consultes::classcomp::operator() (const Text& lhs, const Text& rhs) const
{
    return lhs.consultar_titol() < rhs.consultar_titol();
}

void Consultes::processar_consulta(string consulta, Conjunt_autors autors, Conjunt_cites cites) {
	this->autors = autors;
	this->cites = cites;
	istringstream iss(consulta);
	string paraula;
	iss >> paraula;
	if (paraula == "tots") tots(consulta.substr(paraula.size()));
	else if (paraula == "info") info(consulta.substr(paraula.size()));
	else if (paraula == "frases") frases(consulta.substr(paraula.size()));
	else if (paraula == "nombre") nombre_de(consulta.substr(paraula.size()));
	else if (paraula == "cites") cites_consultar(consulta.substr(paraula.size()));
	else if (paraula == "textos") {
		string nom;
		iss >> paraula; //llegeix autor
		iss >> paraula;
		bool llegit = false;
		while (!llegit) {
			if (paraula[paraula.size()-1] == '\"') {
				llegit = true;
			}
			nom += " " + paraula;
			iss >> paraula;
		}
		textos_autor(nom.substr(2, nom.size()-3));
	}
	else if (paraula == "totes") totes_cites();
	else if (paraula == "autor") autor();
	else if (paraula == "contingut") contingut();
	else if (paraula == "taula") taula_de_frequencies();
}

void Consultes::tots(string consulta) {
	istringstream iss(consulta);
	string paraula;
	iss >> paraula;
	if (paraula == "textos") tots_textos();
	else if (paraula == "autors") tots_autors();
}
void Consultes::tots_textos() {
	vector<string> textos = autors.tots_textos();
	for (int i = 0; i < textos.size();  i++) cout << textos[i] << endl;
}

void Consultes::tots_autors() {
	vector<string> aux = autors.tots_autors();
	for (int i = 0; i < aux.size();  i++) {
    if (aux[i] != "") cout << aux[i] << endl;
  }
}

void Consultes::totes_cites() {
	vector<Cita> aux = cites.totes_cites(autors);
	for (int i = 0; i < aux.size(); i++) {
		//Cita cita = aux[i];
		escriure_cita(aux[i]);
		cout << aux[i].consultar_nom_autor() << " ";
		cout << "\"" << aux[i].consultar_titol() << "\"" << endl;
	}
}

void Consultes::info(string consulta) {
	istringstream iss(consulta);
	string paraula;
	iss >> paraula;
	if (paraula == "cita") {
		string referencia;
		iss >> referencia;
		info_cita(referencia.substr(1,referencia.size()-2));
	}
	else {
		if (autors.hi_ha_text_seleccionat()) {
			string titol_text_seleccionat = autors.obtenir_text_seleccionat();
			string nom_autor_text_seleccionat = autors.obtenir_autor_text_seleccionat();
			Text text = autors.obtenir_text_autor(nom_autor_text_seleccionat, titol_text_seleccionat);
			//info text
			cout << nom_autor_text_seleccionat << " ";
			cout << "\"" << titol_text_seleccionat << "\" ";
			cout << text.consultar_numero_frases() << " " << text.consultar_numero_paraules() << endl;
			//cites associades
			cout << "Cites Associades:" << endl;
			vector<Cita> aux = cites.cites_text_seleccionat(titol_text_seleccionat, autors);
			for (int c = 0; c < aux.size(); c++) {
				escriure_cita(aux[c]);
			}
		}
		else cout << "error" << endl;
	}
}

void Consultes::info_cita(string referencia) {
	Cita cita = cites.cita_referencia(referencia, autors);
	if (cita.consultar_titol() != "NULL") {
		cout << cita.consultar_nom_autor() << " ";
		cout << "\"" << cita.consultar_titol() << "\"" << endl;
		cout << cita.obtenir_frases().begin()->first << "-" << cita.obtenir_frases().rbegin()->first << endl;

  	map<int, string> frases = cita.obtenir_frases();
  	map<int, string>::iterator it = frases.begin();
  	while (it != frases.end()) {
  		cout << it->first << " " << it->second << endl;
  		it++;
  	}
	} else {
		cout << "error" << endl;
	}
}

void Consultes::frases(string consulta) {
	istringstream iss(consulta);
	char lletra;
	iss >> lletra;
	if (lletra >= '0' and lletra <= '9') {
		int x = lletra - 48, y;
		iss >> y;
		frases_text_triat(x,y);
	}
	else if (lletra == '\(') {
		frases_expressio(consulta.substr(1, consulta.size()));
	}
	else if (lletra == '\"') {
		string paraula;
		iss >> paraula;
		vector<string> paraules;
		bool llegit = false;
		while(!llegit) {
			if (paraula[paraula.size()-1] == '\"') {
				paraula = paraula.substr(0, paraula.size()-1);
				llegit = true;
			}
			paraules.push_back(paraula);
			iss >> paraula;
		}
		frases_sequencia(paraules);
	}
}

void Consultes::frases_text_triat(int x, int y) {
	if (autors.hi_ha_text_seleccionat()) {
		string titol_text = autors.obtenir_text_seleccionat();
		string nom_autor = autors.existeix_titol(titol_text);
		Text text = autors.obtenir_text_autor(nom_autor, titol_text);
		if (x >= 1 and (y >= x and y <= text.consultar_numero_frases())) {
			map<int, string> frases = text.consultar_frases(x, y);
			map<int, string>::iterator it = frases.begin();
			while (it != frases.end()) {
				cout << it->first << " " << it->second << endl;
				it++;
			}
		}
		else cout << "error" << endl;
	}
	else cout << "error" << endl;
}

void Consultes::frases_expressio(string expressio) {
	if (autors.hi_ha_text_seleccionat()) {
	    expressio = expressio.substr(1, expressio.size()-2);
	    string titol_text = autors.obtenir_text_seleccionat();
	    string nom_autor = autors.existeix_titol(titol_text);

	    Text text = autors.obtenir_text_autor(nom_autor, titol_text);
	    vector<string> frases = text.consultar_contingut();
	    vector<string>::iterator it = frases.begin();
	    int i = 1;
	    while (it != frases.end()) {
	      //cout << "intentem trobar" << endl;
	      if (frases_expressio_algebraica(expressio, /* *it*/text, i)) {
	        cout << i << " " << *it << endl;
	      }
	      i++;
	      it++;
	    }
	} else {
    	cout << "error" << endl;
	}
}

bool Consultes::frases_expressio_algebraica(string consulta, Text text, int f) {
	/* La idea es fer crides recursives per cada expresió, es a dir,
	per tots els subconjunts de caracters inclosos entre els parentesis '(' i ')'
	Partint de la idea que:
    	- conjunt_de_paraules = '{' + paraula* + '}'.
    	- expressió = '(' + (expressió|conjunt_de_paraules) + ')'. */
	/*
	Forma del programa:
    	expressio_exquerre = obtenir_expressio;
    	operand = obtenir_operand;
		expressio_dreta = obtenir_expressio;
		return expressio_esquerre operand expressio_dreta;
	*/
	//cout << consulta << endl;
	string expressio_e, expressio_d, operand;
	bool resultat_e_e, resultat_e_d;
	int posicio_lectura = 0;
	//obtenir_expressio_esquerre
	if (consulta[0] == '(') { //en cas que sigui una expressio composta, la recollim i fem recursivitat.
      int par = 1;
	    expressio_e = "";
	    posicio_lectura = 1;
      if (consulta[posicio_lectura] == ')') par--;
      else if (consulta[posicio_lectura] == '(') par++;
	    while (par > 0) {
        if (consulta[posicio_lectura+1] == ')') par--;
        else if (consulta[posicio_lectura+1] == '(') par++;
	      expressio_e += consulta[posicio_lectura];
        //cout << consulta[posicio_lectura] << endl;
        posicio_lectura++;
	    }
      //cout << "FORA ESQUERRE: " << consulta[posicio_lectura] << endl;
	    posicio_lectura++;
	    resultat_e_e = frases_expressio_algebraica(expressio_e, text, f);
	} else { //en cas que sigui una expressio simple, la tractem.
	    expressio_e = "";
	    posicio_lectura = 1;
	    while (consulta[posicio_lectura] != '}') {
	      expressio_e += consulta[posicio_lectura];
	      posicio_lectura++;
	    }
	    posicio_lectura++;
	    vector<string> paraules = split(expressio_e, ' ');
	    resultat_e_e = true;

	    for(int i = 0 ; i < paraules.size() && resultat_e_e ; i++) {
	    	if (!text.conte_paraula(paraules[i], f)) resultat_e_e = false;
	    }
	}
	while (consulta[posicio_lectura] != '(' && consulta[posicio_lectura] != '{') {
	    if (consulta[posicio_lectura] == '&' || consulta[posicio_lectura] == '|') {
	    	operand = consulta[posicio_lectura];
    	}
    	posicio_lectura++;
	}

	//obtenir_expressio_dreta
	if (consulta[posicio_lectura] == '(') { //en cas que sigui una expressio composta, la recollim i fem recursivitat.
	    expressio_d = "";
	    posicio_lectura++;
      int par = 1;
      if (consulta[posicio_lectura] == ')') par--;
      else if (consulta[posicio_lectura] == '(') par++;
	    while (par > 0) {
        if (consulta[posicio_lectura+1] == ')') par--;
        else if (consulta[posicio_lectura+1] == '(') par++;
	      expressio_d += consulta[posicio_lectura];
        //cout << consulta[posicio_lectura] << endl;
        posicio_lectura++;
	    }
      //cout << "FORA DRETA: " << consulta[posicio_lectura] << endl;
	    posicio_lectura++;
	    resultat_e_d = frases_expressio_algebraica(expressio_d, text, f);
	} else { //en cas que sigui una expressio simple, la tractem.
	    expressio_d = "";
	    posicio_lectura++;
	    while (consulta[posicio_lectura] != '}') {
	    	expressio_d += consulta[posicio_lectura];
	    	posicio_lectura++;
	    }
	    posicio_lectura++;
	    vector<string> paraules = split(expressio_d, ' ');
	    resultat_e_d = true;

		for(int i = 0 ; i < paraules.size() && resultat_e_d ; i++) {
	    	if (!text.conte_paraula(paraules[i], f)) resultat_e_d = false;
	    }
	}
  //cout << "Resultat: " << expressio_e << " = " << resultat_e_e << " | " << expressio_d << " = " << resultat_e_d << endl;
	return (operand == "&") ? (resultat_e_e && resultat_e_d) : (resultat_e_e || resultat_e_d);
}

bool Consultes::conte_paraula (string paraula, const string frase) {
	vector<string> f = split(frase, ' ');
	for (int i = 0; i < f.size(); ++i) {
		if (f[i] == paraula) return true;
	}
	return false;
}

void Consultes::frases_sequencia(vector<string> paraules) {
	if(autors.hi_ha_text_seleccionat()) {
		string titol_text = autors.obtenir_text_seleccionat();
		string nom_autor = autors.existeix_titol(titol_text);
		Text text = autors.obtenir_text_autor(nom_autor, titol_text);
		int n = text.consultar_numero_frases();
		for (int i = 1; i <= n; i++) {
			if(text.conte_paraules(i, paraules)) {
				cout << i << " " << text.consultar_frase(i) << endl;
			}
		}
	}
	else cout << "error" << endl;
}

void Consultes::nombre_de(string consulta) {
	istringstream iss(consulta);
	string paraula;
	iss >> paraula; //llegeix de
	iss >> paraula;
	if (paraula == "frases") nombre_de_frases();
	else if (paraula == "paraules") nombre_de_paraules();
}

void Consultes::nombre_de_frases() {
	if (autors.hi_ha_text_seleccionat()) {
		string titol_text = autors.obtenir_text_seleccionat();
		string nom_autor = autors.existeix_titol(titol_text);
		Text text = autors.obtenir_text_autor(nom_autor, titol_text);
		cout << text.consultar_numero_frases() << endl;
	}
	else cout << "error" << endl;
}

void Consultes::nombre_de_paraules() {
	if (autors.hi_ha_text_seleccionat()) {
		string titol_text = autors.obtenir_text_seleccionat();
		string nom_autor = autors.existeix_titol(titol_text);
		Text text = autors.obtenir_text_autor(nom_autor, titol_text);
		cout << text.consultar_numero_paraules() << endl;
	}
	else cout << "error" << endl;
}

void Consultes::cites_consultar(string consulta) {
	istringstream iss(consulta);
	string paraula;
	iss >> paraula;
	if (paraula == "autor") {
		string nom;
		iss >> paraula;
		bool llegit = false;
		while (!llegit) {
			if (paraula[paraula.size()-1] == '\"') {
				llegit = true;
			}
			nom += " " + paraula;
			iss >> paraula;
		}
		cites_autor(nom.substr(2, nom.size()-3), autors);
	}
	else {
		vector<Cita> aux = cites.cites_text_seleccionat(autors.obtenir_text_seleccionat(), autors);
		for (int c = 0; c < aux.size(); c++) {
			escriure_cita(aux[c]);
      cout << aux[c].consultar_nom_autor() << " \"" << aux[c].consultar_titol() << "\"" << endl;
		}
	}
}

void Consultes::cites_autor(string nom, Conjunt_autors) {
	vector<Cita> aux = cites.cites_autor(nom, autors);
	for (int c = 0; c < aux.size(); c++) {
		escriure_cita(aux[c]);
    cout << "\"" << aux[c].consultar_titol() << "\"" << endl;
	}
}

void Consultes::textos_autor(string nom) {
	const Autor autor = autors.obtenir_autor(nom);
	vector<string> textos = autor.consultar_titol_textos();
	for (int i = 0; i < textos.size(); i++) {
		cout << "\"" << textos[i] << "\"" << endl;
	}
}

void Consultes::autor() {
	if (autors.hi_ha_text_seleccionat()) {
		string autor = autors.obtenir_autor_text_seleccionat();
		cout << autor << endl;
	}
	else cout << "error" << endl;
}

void Consultes::contingut() {
	if (autors.hi_ha_text_seleccionat()) {
		string titol_text = autors.obtenir_text_seleccionat();
		string nom_autor = autors.existeix_titol(titol_text);
		Text text = autors.obtenir_text_autor(nom_autor, titol_text);
		vector<string> frases = text.consultar_contingut();
		for (int i = 0; i < frases.size(); i++) {
			cout << i+1 << " " << frases[i] << endl;
		}
	}
	else cout << "error" << endl;
}

void Consultes::taula_de_frequencies() {
	string titol_text = autors.obtenir_text_seleccionat();
	string nom_autor = autors.existeix_titol(titol_text);
	Text text = autors.obtenir_text_autor(nom_autor, titol_text);
	vector<vector<string> > taula = text.consultar_taula_frequencies();
	for (int i = taula.size()-1; i > 0; i--) {
		for (int j = 0; j < taula[i].size(); j++){
			cout << taula[i][j] << " " << i << endl;
		}
	}
}

void Consultes::escriure_cita(Cita& cita) {
	cout << cita.consultar_referencia() << endl;
	map<int, string> frases = cita.obtenir_frases();
	map<int, string>::iterator it = frases.begin();
	while (it != frases.end()) {
		cout << it->first << " " << it->second << endl;
		it++;
	}
}

void Consultes::escriure_frases_cita(Cita& cita) {
	map<int, string> frases = cita.obtenir_frases();
	map<int, string>::iterator it = frases.begin();
	while (it != frases.end()) {
		cout << it->first << " " << it->second << endl;
		it++;
	}
}

vector<string> Consultes::split(string str, char delimiter) {
	vector<string> internal;
	stringstream ss(str); // Turn the string into a stream.
	string tok;

	while(getline(ss, tok, delimiter)) {
    	internal.push_back(tok);
	}

	return internal;
}
