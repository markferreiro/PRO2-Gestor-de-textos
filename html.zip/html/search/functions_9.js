var searchData=
[
  ['text',['Text',['../class_text.html#a3ed11205339416811035dfa10a7652c5',1,'Text::Text(string titol, vector&lt; vector&lt; string &gt; &gt; frases)'],['../class_text.html#a8ab6e6897616db3f47500b4b3813a0ea',1,'Text::Text(string titol)']]],
  ['totes_5fcites',['totes_cites',['../class_conjunt__cites.html#abed802b0d1d6b5bdbfd28a4a7a598257',1,'Conjunt_cites']]],
  ['tots_5fautors',['tots_autors',['../class_conjunt__autors.html#abdd648601a6a96537953185a456dea13',1,'Conjunt_autors']]],
  ['tots_5ftextos',['tots_textos',['../class_autor.html#aaec3ac87a2fa3c41aa24bfe91c3757f1',1,'Autor::tots_textos()'],['../class_conjunt__autors.html#abd854de76bc2696a655e3ba352e98a82',1,'Conjunt_autors::tots_textos()']]],
  ['triar_5ftext',['triar_text',['../class_conjunt__autors.html#a81ecf976dcc18b23d542f86e2705faed',1,'Conjunt_autors::triar_text()'],['../class_gestor__de__textos.html#a6517c4f51f844360af0541357ab49572',1,'Gestor_de_textos::triar_text()']]]
];
