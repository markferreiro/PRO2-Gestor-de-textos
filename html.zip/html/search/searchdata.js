var indexSectionsWithContent =
{
  0: "aceghimnost",
  1: "acgt",
  2: "acgt",
  3: "acehimnost"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions"
};

