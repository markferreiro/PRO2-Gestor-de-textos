var searchData=
[
  ['modificar_5ftitol',['modificar_titol',['../class_text.html#a14af1ae0bb7478f801760f3c9562de3b',1,'Text']]]
];
