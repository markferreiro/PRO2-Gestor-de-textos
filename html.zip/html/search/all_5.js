var searchData=
[
  ['inttostring',['IntToString',['../class_conjunt__autors.html#add4e33818f409c16332c163d8fcb797c',1,'Conjunt_autors::IntToString()'],['../class_conjunt__cites.html#a10e5e5b4c5a3cce568c8b88e30273748',1,'Conjunt_cites::IntToString()']]]
];
