var searchData=
[
  ['nombre_5fde_5ffrases',['nombre_de_frases',['../class_autor.html#afada6928eb371646e37b34bf487b3f77',1,'Autor']]],
  ['nombre_5fde_5fparaules',['nombre_de_paraules',['../class_autor.html#a9653880b41ba494c778bc7cb9c180ecf',1,'Autor']]],
  ['nombre_5fde_5ftextos',['nombre_de_textos',['../class_autor.html#a37a2a924f29ebb3821270dcdada6b2e6',1,'Autor']]]
];
