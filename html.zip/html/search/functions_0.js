var searchData=
[
  ['afegir',['afegir',['../class_gestor__de__textos.html#aff2f85d7a29e2bb2631bbaf832d27026',1,'Gestor_de_textos']]],
  ['afegir_5fautor',['afegir_autor',['../class_conjunt__autors.html#adb64d489967e5741aec27bc55cee0a6e',1,'Conjunt_autors']]],
  ['afegir_5fcita',['afegir_cita',['../class_conjunt__cites.html#aa18d231e9cf045ac12f2eddb19ce2903',1,'Conjunt_cites']]],
  ['afegir_5fcontingut',['afegir_contingut',['../class_text.html#aa7c10724cb1dfb954286c392c668ec35',1,'Text']]],
  ['afegir_5ftext',['afegir_text',['../class_autor.html#a115b7d17489060d79a4c00c2fe121fa7',1,'Autor']]],
  ['afegir_5ftext_5fa_5fautor',['afegir_text_a_autor',['../class_conjunt__autors.html#a7799a43db3b3c03884ee48277e3a0956',1,'Conjunt_autors']]],
  ['autor',['Autor',['../class_autor.html#a1f5864cb38ae97d90506b6d6be43eacc',1,'Autor']]]
];
