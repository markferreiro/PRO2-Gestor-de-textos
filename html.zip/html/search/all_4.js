var searchData=
[
  ['hi_5fha_5ftext_5fseleccionat',['hi_ha_text_seleccionat',['../class_conjunt__autors.html#abddabbb28f6e92b148de755458318900',1,'Conjunt_autors']]]
];
