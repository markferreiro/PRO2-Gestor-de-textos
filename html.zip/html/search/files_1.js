var searchData=
[
  ['cita_2ehh',['Cita.hh',['../_cita_8hh.html',1,'']]],
  ['conjunt_5fautors_2ehh',['Conjunt_autors.hh',['../_conjunt__autors_8hh.html',1,'']]],
  ['conjunt_5fcites_2ehh',['Conjunt_cites.hh',['../_conjunt__cites_8hh.html',1,'']]],
  ['consultes_2ehh',['Consultes.hh',['../_consultes_8hh.html',1,'']]]
];
