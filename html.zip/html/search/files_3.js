var searchData=
[
  ['text_2ehh',['Text.hh',['../_text_8hh.html',1,'']]]
];
