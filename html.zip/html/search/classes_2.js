var searchData=
[
  ['gestor_5fde_5ftextos',['Gestor_de_textos',['../class_gestor__de__textos.html',1,'']]]
];
