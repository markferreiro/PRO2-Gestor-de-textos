var searchData=
[
  ['obtenir_5fautor',['obtenir_autor',['../class_conjunt__autors.html#aa667826ee4314b31b2014b41f03d9eb9',1,'Conjunt_autors']]],
  ['obtenir_5fautor_5ftext_5fseleccionat',['obtenir_autor_text_seleccionat',['../class_conjunt__autors.html#acc2c44f568f6bc1cf76b95410fe36c7e',1,'Conjunt_autors']]],
  ['obtenir_5fconjunt_5fautors',['obtenir_conjunt_autors',['../class_gestor__de__textos.html#af7a18f9cf5952aa20bc82084df1be895',1,'Gestor_de_textos']]],
  ['obtenir_5fconjunt_5fcites',['obtenir_conjunt_cites',['../class_gestor__de__textos.html#a2431b7e6f66f62f572f8965b82802bdb',1,'Gestor_de_textos']]],
  ['obtenir_5ffrases',['obtenir_frases',['../class_cita.html#ab6920244af1e1893686a33165f13e734',1,'Cita']]],
  ['obtenir_5ftext',['obtenir_text',['../class_autor.html#a1bddc06f3d7af95807e8aaba68ca1e7c',1,'Autor']]],
  ['obtenir_5ftext_5fautor',['obtenir_text_autor',['../class_conjunt__autors.html#aece7a6bb04cf7cb0a73ac11658471876',1,'Conjunt_autors']]],
  ['obtenir_5ftext_5fseleccionat',['obtenir_text_seleccionat',['../class_conjunt__autors.html#a072b553a53360b62bf3b5e75596f688f',1,'Conjunt_autors']]]
];
