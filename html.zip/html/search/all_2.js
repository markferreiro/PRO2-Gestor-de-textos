var searchData=
[
  ['eliminar',['eliminar',['../class_gestor__de__textos.html#a703e846227b30adcde2928f9d856b929',1,'Gestor_de_textos']]],
  ['eliminar_5fautor',['eliminar_autor',['../class_conjunt__autors.html#a659162eb03449b1cf62f2f9d8ecd8bd8',1,'Conjunt_autors']]],
  ['eliminar_5fcita',['eliminar_cita',['../class_conjunt__cites.html#a0af3330982d741360f9b22e086c6cea3',1,'Conjunt_cites']]],
  ['eliminar_5ftext',['eliminar_text',['../class_autor.html#ac0ef7bba037924dbcec45e650262e504',1,'Autor']]],
  ['eliminar_5ftext_5fde_5fautor',['eliminar_text_de_autor',['../class_conjunt__autors.html#a2d029b5b7479ccd46c0348d306bf534b',1,'Conjunt_autors']]],
  ['esborrar_5ftext_5ftriat',['esborrar_text_triat',['../class_conjunt__autors.html#adf0d7d70daf46d60caa61db0fb7e46e2',1,'Conjunt_autors']]],
  ['existeix_5fparaula',['existeix_paraula',['../class_text.html#a470664d8ec4fcc39fa096024fcfc32ea',1,'Text']]],
  ['existeix_5ftext',['existeix_text',['../class_autor.html#aa528244c536649aee5fe902cad056390',1,'Autor']]],
  ['existeix_5ftext_5famb_5fparaules',['existeix_text_amb_paraules',['../class_autor.html#abb25e15986a496dac4b49522402d5661',1,'Autor']]],
  ['existeix_5ftitol',['existeix_titol',['../class_autor.html#a526b689049edfbbf962a6bf25855d268',1,'Autor::existeix_titol()'],['../class_conjunt__autors.html#a88b7d991775558d6d27619215d715e03',1,'Conjunt_autors::existeix_titol()']]]
];
