var searchData=
[
  ['cita',['Cita',['../class_cita.html',1,'']]],
  ['classcomp',['classcomp',['../struct_conjunt__autors_1_1classcomp.html',1,'Conjunt_autors']]],
  ['conjunt_5fautors',['Conjunt_autors',['../class_conjunt__autors.html',1,'']]],
  ['conjunt_5fcites',['Conjunt_cites',['../class_conjunt__cites.html',1,'']]],
  ['consultes',['Consultes',['../class_consultes.html',1,'']]],
  ['custom_5fsort',['custom_sort',['../struct_autor_1_1custom__sort.html',1,'Autor']]]
];
