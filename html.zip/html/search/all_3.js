var searchData=
[
  ['gestor_5fde_5ftextos',['Gestor_de_textos',['../class_gestor__de__textos.html',1,'']]],
  ['gestor_5fde_5ftextos_2ehh',['Gestor_de_textos.hh',['../_gestor__de__textos_8hh.html',1,'']]]
];
