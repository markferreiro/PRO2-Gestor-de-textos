var searchData=
[
  ['substitueix_5fparaula',['substitueix_paraula',['../class_text.html#a946894e3557c696bf98cf64298d87176',1,'Text']]],
  ['substituir_5fparaules',['substituir_paraules',['../class_gestor__de__textos.html#a41b041a6622f9a5b35f0be26b492e823',1,'Gestor_de_textos']]]
];
